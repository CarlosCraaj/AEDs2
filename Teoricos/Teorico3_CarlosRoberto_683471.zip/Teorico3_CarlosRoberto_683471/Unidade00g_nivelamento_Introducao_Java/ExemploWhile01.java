class ExemploWhile01
{
    public static void main(String[] args)
    {
        int n = 1;

        while(n <= 10)
        {
            MyIO.println(n*2);
            n++;
        }
    }
}